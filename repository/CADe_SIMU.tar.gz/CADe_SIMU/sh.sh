dpkg --add-architecture i386
apt-get update
apt-get install wine32

cp cadesimu.desktop /home/usuario/Desktop

echo "4962"
